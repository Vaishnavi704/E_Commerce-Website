from flask import Flask, render_template, send_from_directory, request, redirect, url_for, session, abort
import mysql.connector
import os
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Used for session management

# MySQL connection
db = mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="vaish",
    database="E_Commerce"
)

@app.route('/')
def index():
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM featured_products")
        products = cursor.fetchall()

        cursor.execute("SELECT * FROM vibe")
        vibes = cursor.fetchall()

        for product in products:
            product['page_link'] = f"/featured/{product['id']}"

        return render_template('index.html', products=products, vibe=vibes)
    finally:
        cursor.close()

@app.route('/featured/<int:product_id>')
def show_featured_product(product_id):
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM featured_products WHERE id = %s", (product_id,))
        product = cursor.fetchone()

        if product:
            html_filename = product['link']
            template_path = os.path.join(app.template_folder, html_filename)
            if os.path.exists(template_path):
                user_id = session.get('user_id')
                return render_template(html_filename, product=product, user_id=user_id)
            else:
                return "Template not found", 404
        else:
            return abort(404)
    finally:
        cursor.close()

@app.route('/cart')
def cart():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute(
            """
            SELECT c.id, c.quantity, c.total_price, 
                COALESCE(p.name, p2.name, p3.name, p4.name) AS name, 
                COALESCE(p.price, p2.price, p3.price, p4.price) AS price, 
                COALESCE(p.image_path, p2.image_path, p3.image_path, p4.image_path) AS image_path
            FROM cart c 
            LEFT JOIN featured_products p ON c.product_id = p.id AND c.product_type = 'featured'
            LEFT JOIN party p2 ON c.product_id = p2.id AND c.product_type = 'party'
            LEFT JOIN casual p3 ON c.product_id = p3.id AND c.product_type = 'casual'
            LEFT JOIN festive p4 ON c.product_id = p4.id AND c.product_type = 'festive'
            WHERE c.user_id = %s
            """,
            (session['user_id'],)
        )
        cart_items = cursor.fetchall()

        total_price = sum(
            (item['total_price'] if item['total_price'] is not None else 0)
            for item in cart_items
        )

        return render_template('cart.html', cart_items=cart_items, total_price=total_price)
    finally:
        cursor.close()

@app.route('/remove-from-cart/<int:item_id>', methods=['POST'])
def remove_from_cart(item_id):
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("DELETE FROM cart WHERE id = %s AND user_id = %s", (item_id, session['user_id']))
        db.commit()
    finally:
        cursor.close()

    return redirect(url_for('cart'))

@app.route('/update-cart/<int:item_id>', methods=['POST'])
def update_cart(item_id):
    new_quantity = int(request.form.get('quantity'))

    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute(
            """
            SELECT COALESCE(p.price, p2.price, p3.price, p4.price) AS price
            FROM cart c
            LEFT JOIN featured_products p ON c.product_id = p.id AND c.product_type = 'featured'
            LEFT JOIN party p2 ON c.product_id = p2.id AND c.product_type = 'party'
            LEFT JOIN casual p3 ON c.product_id = p3.id AND c.product_type = 'casual'
            LEFT JOIN festive p4 ON c.product_id = p4.id AND c.product_type = 'festive'
            WHERE c.id = %s
            """,
            (item_id,)
        )
        product = cursor.fetchone()

        if product:
            price_per_unit = float(product['price'].replace(',', ''))
            updated_price = price_per_unit * new_quantity

            cursor.execute("UPDATE cart SET quantity = %s, total_price = %s WHERE id = %s",
                           (new_quantity, updated_price, item_id))
            db.commit()
    finally:
        cursor.close()

    return redirect(url_for('cart'))

@app.route('/add_to_cart/<int:product_id>', methods=['POST'])
def add_to_cart(product_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM featured_products WHERE id = %s", (product_id,))
        product = cursor.fetchone()

        if product:
            cursor.execute(
                "SELECT * FROM cart WHERE user_id = %s AND product_id = %s AND product_type = 'featured'",
                (session['user_id'], product_id)
            )
            existing_cart_item = cursor.fetchone()

            if existing_cart_item:
                cursor.execute(
                    "UPDATE cart SET quantity = quantity + 1 WHERE user_id = %s AND product_id = %s AND product_type = 'featured'",
                    (session['user_id'], product_id)
                )
            else:
                cursor.execute(
                    "INSERT INTO cart (user_id, product_id, quantity, product_type) VALUES (%s, %s, %s, 'featured')",
                    (session['user_id'], product_id, 1)
                )
            db.commit()
            return redirect(url_for('cart'))
        else:
            return abort(404)
    finally:
        cursor.close()

@app.route('/add_to_cart_party/<int:product_id>', methods=['POST'])
def add_to_cart_party(product_id):
    if 'user_id' not in session:
        return "User not logged in", 403

    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM party WHERE id = %s", (product_id,))
        product = cursor.fetchone()

        if not product:
            return "Product not found", 404

        cursor.execute(
            "INSERT INTO cart (user_id, product_id, quantity, product_type) VALUES (%s, %s, %s, 'party')",
            (session['user_id'], product_id, 1)
        )
        db.commit()
        return redirect(url_for('cart'))
    finally:
        cursor.close()

        

# Similarly you can create add_to_cart_casual and add_to_cart_festive routes if needed

@app.route('/add_to_cart_casual/<int:product_id>', methods=['POST'])
def add_to_cart_casual(product_id):
    if 'user_id' not in session:
        return "User not logged in", 403

    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM casual WHERE id = %s", (product_id,))
        product = cursor.fetchone()

        if not product:
            return "Product not found", 404

        cursor.execute(
            "INSERT INTO cart (user_id, product_id, quantity, product_type) VALUES (%s, %s, %s, 'casual')",
            (session['user_id'], product_id, 1)
        )
        db.commit()
        return redirect(url_for('cart'))
    finally:
        cursor.close()

@app.route('/add_to_cart_festive/<int:product_id>', methods=['POST'])
def add_to_cart_festive(product_id):
    if 'user_id' not in session:
        return "User not logged in", 403

    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM festive WHERE id = %s", (product_id,))
        product = cursor.fetchone()

        if not product:
            return "Product not found", 404

        cursor.execute(
            "INSERT INTO cart (user_id, product_id, quantity, product_type) VALUES (%s, %s, %s, 'festive')",
            (session['user_id'], product_id, 1)
        )
        db.commit()
        return redirect(url_for('cart'))
    finally:
        cursor.close()


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']

        hashed_password = generate_password_hash(password)

        cursor = db.cursor(dictionary=True)
        try:
            cursor.execute(
                "INSERT INTO users (username, password, email) VALUES (%s, %s, %s)",
                (username, hashed_password, email)
            )
            db.commit()
            return redirect(url_for('login'))
        finally:
            cursor.close()

    return render_template('signup.html')

@app.route('/images/<filename>')
def serve_image(filename):
    return send_from_directory('images', filename)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cursor = db.cursor(dictionary=True)
        try:
            cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
            user = cursor.fetchone()

            if user and check_password_hash(user['password'], password):
                session['user_id'] = user['id']
                return redirect(url_for('index'))
            else:
                error = "Invalid username or password"
                return render_template('login.html', error=error)
        finally:
            cursor.close()

    return render_template('login.html')

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT username, email, address FROM users WHERE id = %s", (session['user_id'],))
        user = cursor.fetchone()

        cursor.execute("SELECT * FROM orders WHERE user_id = %s", (session['user_id'],))
        orders = cursor.fetchall()

        return render_template('profile.html', user=user, orders=orders)
    finally:
        cursor.close()

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.template_filter('to_float')
def to_float(value):
    try:
        return float(value.replace(',', ''))
    except ValueError:
        return 0.0

@app.route('/checkout')
def checkout():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute(
            """
            SELECT c.id, c.quantity, 
                COALESCE(p.name, p2.name, p3.name, p4.name) AS name,
                COALESCE(p.price, p2.price, p3.price, p4.price) AS price,
                COALESCE(p.image_path, p2.image_path, p3.image_path, p4.image_path) AS image_path
            FROM cart c
            LEFT JOIN featured_products p ON c.product_id = p.id AND c.product_type = 'featured'
            LEFT JOIN party p2 ON c.product_id = p2.id AND c.product_type = 'party'
            LEFT JOIN casual p3 ON c.product_id = p3.id AND c.product_type = 'casual'
            LEFT JOIN festive p4 ON c.product_id = p4.id AND c.product_type = 'festive'
            WHERE c.user_id = %s
            """,
            (session['user_id'],)
        )
        cart_items = cursor.fetchall()

        for item in cart_items:
            item['price'] = float(item['price'].replace(',', ''))

        total_price = sum(item['price'] * item['quantity'] for item in cart_items)

        return render_template('checkout.html', cart_items=cart_items, total_price=total_price)
    finally:
        cursor.close()

@app.route('/process_payment', methods=['POST'])
def process_payment():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM cart WHERE user_id = %s", (session['user_id'],))
    cart_items = cursor.fetchall()
    cursor.close()

    return render_template('process_payment.html', cart_items=cart_items)

@app.route('/confirm_order', methods=['POST'])
def confirm_order():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    address = request.form['address']
    cursor = db.cursor(dictionary=True)

    try:
        cursor.execute("SELECT * FROM cart WHERE user_id = %s", (session['user_id'],))
        cart_items = cursor.fetchall()

        for item in cart_items:
            # Check if the product exists in either featured_products or party table
            cursor.execute("SELECT id FROM featured_products WHERE id = %s", (item['product_id'],))
            product_in_featured = cursor.fetchone()

            cursor.execute("SELECT id FROM party WHERE id = %s", (item['product_id'],))
            product_in_party = cursor.fetchone()
            

            # If the product doesn't exist in either table, skip this item
            if not product_in_featured and not product_in_party:
                print(f"Product ID {item['product_id']} does not exist in either featured_products or party.")
                continue  # Skip this item if product doesn't exist

            # Fetch price from featured_products first
            if product_in_featured:
                cursor.execute("SELECT price FROM featured_products WHERE id = %s", (item['product_id'],))
                price_data = cursor.fetchone()
            # If not found in featured_products, fetch from party
            elif product_in_party:
                cursor.execute("SELECT price FROM party WHERE id = %s", (item['product_id'],))
                price_data = cursor.fetchone()

            if not price_data:
                # Handle case where price is not found
                print(f"Price for Product ID {item['product_id']} not found.")
                continue

            # Remove commas from price string (if any)
            price_str = price_data['price']
            price_str = price_str.replace(",", "")  # Remove commas from the price

            # Convert price to decimal
            try:
                price = float(price_str)
            except ValueError:
                print(f"Invalid price value: {price_str} for Product ID {item['product_id']}")
                continue

            # Insert order if price is valid
            cursor.execute(
                "INSERT INTO orders (user_id, product_id, quantity, address, total_price) VALUES (%s, %s, %s, %s, %s)",
                (session['user_id'], item['product_id'], item['quantity'], address, price * item['quantity'])
            )

        # Empty the cart after successful order insertion
        cursor.execute("DELETE FROM cart WHERE user_id = %s", (session['user_id'],))
        db.commit()

        return redirect(url_for('profile'))

    except Exception as e:
        db.rollback()  # Rollback any changes in case of error
        print(f"Error: {str(e)}")
        return str(e)

    finally:
        cursor.close()

@app.route('/Casual.html')
def show_casual():
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT id, name, price, image_path FROM casual")
    casual_products = cursor.fetchall()
    return render_template('Casual.html', casual=casual_products)

@app.route('/Party.html')
def show_party():
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT id, name, price, image_path FROM party")
    party_products = cursor.fetchall()
    return render_template('Party.html', party=party_products)

@app.route('/Festive.html')
def show_festive():
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT id, name, price, image_path FROM festive")
    festive_products = cursor.fetchall()
    return render_template('Festive.html', festive=festive_products)

if __name__ == "__main__":
    app.run(debug=True)
