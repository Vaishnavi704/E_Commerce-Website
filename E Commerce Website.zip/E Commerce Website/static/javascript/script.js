let currentIndex = 0;
const productSlider = document.querySelector('.product-slider');
const totalProducts = document.querySelectorAll('.product-card').length;
const maxVisibleProducts = 4;  // 4 products at a time
const productWidth = 300 + 20; // card width (300px) + margin-right (20px)

// Function to move the slider
function moveSlider(direction) {
    if (direction === 'left' && currentIndex > 0) {
        currentIndex--;
    } else if (direction === 'right' && currentIndex < totalProducts - maxVisibleProducts) {
        currentIndex++;
    }

    productSlider.style.transform = `translateX(-${currentIndex * productWidth}px)`;
}

// Add event listeners for the arrow buttons
document.querySelector('.left-arrow').addEventListener('click', () => moveSlider('left'));
document.querySelector('.right-arrow').addEventListener('click', () => moveSlider('right'));
